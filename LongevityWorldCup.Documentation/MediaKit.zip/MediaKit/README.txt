Longevity World Cup Media Kit
Updated: July 2026

FactSheet.pdf - Current one-page fact sheet.
FactSheet.txt - Plain-text fact sheet for easy copy and paste.
Hero_LWC_2025.jpg / .png - Legacy launch artwork for the inaugural 2025 season.
Logos/ - Official logo variants (black on white, white on black, black on transparent).
Team/ - Adam Ficsor biography and press images:
  AdamFicsor.jpg - Original candid press photo.
  AdamFicsor2.png - Portrait without added branding.
  AdamFicsor2_logo.png - Portrait with the Longevity World Cup logo.
  AdamFicsor2_lwctext.png - Portrait with the Longevity World Cup name.
  Bio_AdamFicsor.txt - Current Adam Ficsor biography.
  TeamPhoto2025.png - 2025 team graphic.
