Longevity World Cup Media Kit
Updated: July 2026

FactSheet.pdf - Current one-page fact sheet.
FactSheet.txt - Plain-text fact sheet for easy copy and paste.
Hero_LWC_2025.jpg / .png - Legacy launch artwork for the inaugural 2025 season.
Logos/ - Official logo variants (black on white, white on black, black on transparent).
athletes/ - Curated press photos of Longevity World Cup athletes:
  charlotte_wong.webp - Charlotte Wong.
  dave_pascoe.jpg - Dave Pascoe.
  erin_easterly.jpg - Erin Easterly.
  larissa_schmeing.jpg - Larissa Schmeing.
  michael_lustgarten.jpg - Michael Lustgarten, PhD.
  philipp_schmeing.jpg - Philipp Schmeing.
  siim_land.jpg - Siim Land.
  tiat_lim.webp - Tiat Lim.
  valerie_orsoni.jpg - Valerie Orsoni.
  yan_lin.webp - Yan Lin.
Team/ - Adam Ficsor biography and press images:
  AdamFicsor.jpg - Original candid press photo.
  AdamFicsor2.png - Portrait without added branding.
  AdamFicsor2_logo.png - Portrait with the Longevity World Cup logo.
  AdamFicsor2_lwctext.png - Portrait with the Longevity World Cup name.
  Bio_AdamFicsor.txt - Current Adam Ficsor biography.
  TeamPhoto2025.png - 2025 team graphic.
