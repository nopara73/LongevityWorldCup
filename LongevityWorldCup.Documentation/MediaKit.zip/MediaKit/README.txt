FactSheet.pdf – Key facts about the Longevity World Cup.
FactSheet.txt – Plain text version of Fact Sheet for easy copy/paste.
Hero_LWC_2025.jpg / .png – Main hero image for press use.
Logos/ – Official logo variants (black on white, white on black, black on transparent).
Team/ – Team photo, individual bios, and Adam Ficsor press images:
  AdamFicsor.jpg – Original headshot.
  AdamFicsor2.png – Updated portrait.
  AdamFicsor2_logo.png – Updated portrait with the Longevity World Cup logo.
  AdamFicsor2_lwctext.png – Updated portrait with the Longevity World Cup name.
  Bio_AdamFicsor.txt – Adam Ficsor biography.
  TeamPhoto2025.png – Team photo.
