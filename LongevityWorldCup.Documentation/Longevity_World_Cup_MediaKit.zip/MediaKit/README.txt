FactSheet.pdf – Key facts about the Longevity World Cup.
FactSheet.txt – Plain text version of Fact Sheet for easy copy/paste.
Hero_LWC_2025.jpg / .png – Main hero image for press use.
Logos/ – Official logo variants (black on white, white on black, black on transparent).
Team/ – Team photo and individual bios/headshots.